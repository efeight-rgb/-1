(() => {
  "use strict";

  /* ================= Константы (учебная модель) ================= */
  const VENUS_RADIUS = 6051.8;        // км
  const VENUS_MU = 324858.6;          // км^3/с^2 — гравитационный параметр Венеры
  const VENUS_ORBITAL_SPEED = 35.02;  // км/с — орбитальная скорость Венеры
  const START_DISTANCE = 15 * VENUS_RADIUS; // расстояние, с которого начинается расчёт
  const ATMOSPHERE_ALT = 250;         // км — ниже этой высоты аппарат считается потерянным
  const MIN_USEFUL_DELTA = 0.2;       // км/с — порог успеха по |ΔV|
  const ANIMATION_MS = 5200;

  /* ================= Физика ================= */

  // Ускорение в поле тяготения Венеры. state = [x, y, vx, vy] в системе Венеры.
  function derivative(s) {
    const r2 = s[0] * s[0] + s[1] * s[1];
    const k = -VENUS_MU / (r2 * Math.sqrt(r2));
    return [s[2], s[3], k * s[0], k * s[1]];
  }

  function step(s, k, h) {
    return s.map((v, i) => v + k[i] * h);
  }

  function rk4(s, dt) {
    const k1 = derivative(s);
    const k2 = derivative(step(s, k1, dt / 2));
    const k3 = derivative(step(s, k2, dt / 2));
    const k4 = derivative(step(s, k3, dt));
    return s.map((v, i) => v + dt * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) / 6);
  }

  /**
   * Пролёт около Венеры.
   * vInf   — относительная скорость «на бесконечности», км/с
   * alt    — высота перицентра над поверхностью, км
   * side   — +1: аппарат проходит впереди Венеры (y > 0), -1: позади (y < 0)
   *
   * Начальные условия берутся из точного решения для гиперболы, поэтому
   * высота в перицентре совпадает с выбранной. Затем траектория
   * интегрируется методом Рунге — Кутты 4-го порядка с переменным шагом.
   * Система координат: Венера в начале, аппарат летит вдоль +x,
   * Венера в гелиоцентрической системе движется вдоль +y.
   */
  function calculateFlyby(vInf, alt, side) {
    const rp = VENUS_RADIUS + alt;
    const e = 1 + rp * vInf * vInf / VENUS_MU;          // эксцентриситет
    const p = rp * (1 + e);                              // параметр орбиты
    const hMom = Math.sqrt(VENUS_MU * p);                // удельный момент импульса
    const impact = hMom / vInf;                          // прицельный параметр
    const turn = 2 * Math.asin(1 / e);                   // угол отклонения

    // Начальная точка на входящей ветви гиперболы.
    const nu0 = -Math.acos((p / START_DISTANCE - 1) / e);
    const k = VENUS_MU / hMom;
    let x = START_DISTANCE * Math.cos(nu0);
    let y = START_DISTANCE * Math.sin(nu0);
    let vx = -k * Math.sin(nu0);
    let vy = k * (e + Math.cos(nu0));

    // Поворот так, чтобы скорость на бесконечности смотрела вдоль +x.
    const alpha = Math.atan2(e - 1 / e, Math.sqrt(1 - 1 / (e * e)));
    const ca = Math.cos(alpha), sa = Math.sin(alpha);
    [x, y] = [x * ca + y * sa, -x * sa + y * ca];
    [vx, vy] = [vx * ca + vy * sa, -vx * sa + vy * ca];
    if (side === 1) { y = -y; vy = -vy; }                // зеркало: пролёт впереди Венеры

    let state = [x, y, vx, vy];
    let t = 0, path = 0;
    const points = [[x, y, vx, vy, 0, 0]];               // x, y, vx, vy, время, длина пути
    let minR = Math.hypot(x, y), closestIndex = 0, passedPeri = false;

    for (let i = 0; i < 40000; i++) {
      const r = Math.hypot(state[0], state[1]);
      const speed = Math.hypot(state[2], state[3]);
      const dt = Math.min(60, Math.max(0.5, 0.02 * r / speed));
      const next = rk4(state, dt);
      path += Math.hypot(next[0] - state[0], next[1] - state[1]);
      t += dt;
      state = next;
      const rn = Math.hypot(state[0], state[1]);
      points.push([state[0], state[1], state[2], state[3], t, path]);
      if (rn < minR) { minR = rn; closestIndex = points.length - 1; }
      if (rn <= VENUS_RADIUS) break;                     // удар о поверхность
      if (state[0] * state[2] + state[1] * state[3] > 0) passedPeri = true;
      if (passedPeri && rn >= START_DISTANCE) break;
    }

    const crashed = alt <= 0;
    const burned = !crashed && alt < ATMOSPHERE_ALT;
    const failed = crashed || burned;
    const used = failed ? points.slice(0, closestIndex + 1) : points;

    // Скорость после пролёта (на бесконечности): по модулю та же, повёрнута на угол turn.
    const outVx = vInf * Math.cos(turn);
    const outVy = -side * vInf * Math.sin(turn);
    const beforeHelio = Math.hypot(vInf, VENUS_ORBITAL_SPEED);
    const afterHelio = Math.hypot(outVx, outVy + VENUS_ORBITAL_SPEED);

    const last = used[used.length - 1];
    const bounds = { minX: -VENUS_RADIUS * 1.6, maxX: VENUS_RADIUS * 1.6, minY: -VENUS_RADIUS * 1.6, maxY: VENUS_RADIUS * 1.6 };
    used.forEach(q => {
      bounds.minX = Math.min(bounds.minX, q[0]); bounds.maxX = Math.max(bounds.maxX, q[0]);
      bounds.minY = Math.min(bounds.minY, q[1]); bounds.maxY = Math.max(bounds.maxY, q[1]);
    });

    return {
      points: used, closestIndex: Math.min(closestIndex, used.length - 1), bounds,
      elapsed: last[4], totalPath: last[5],
      vInf, side, impact, eccentricity: e,
      minAltitude: Math.max(0, minR - VENUS_RADIUS),
      incomingRelative: vInf, outgoingRelative: Math.hypot(outVx, outVy),
      beforeHelio, afterHelio, delta: afterHelio - beforeHelio,
      turnAngle: turn * 180 / Math.PI,
      crashed, burned, failed
    };
  }

  // Положение аппарата для доли прогресса (по длине пути — движение выглядит плавным).
  function headAt(res, progress) {
    const pts = res.points;
    const target = progress * res.totalPath;
    let lo = 0, hi = pts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (pts[mid][5] < target) lo = mid + 1; else hi = mid;
    }
    const b = pts[lo], a = pts[Math.max(0, lo - 1)];
    const span = b[5] - a[5];
    const f = span > 0 ? (target - a[5]) / span : 0;
    const head = a.map((v, i) => v + (b[i] - v) * f);
    return { head, count: lo };
  }

  /* ================= Интерфейс ================= */
  const $ = (id) => document.getElementById(id);
  const canvas = $("spaceCanvas");
  const ctx = canvas.getContext("2d");
  const speedInput = $("speed");
  const altitudeInput = $("altitude");
  const launchBtn = $("launchBtn");
  const resetBtn = $("resetBtn");
  const sideButtons = document.querySelectorAll(".side-btn");
  const reducedMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  let side = 1;
  let result = null;       // результат последнего запуска (или null)
  let preview = null;      // траектория по текущим настройкам (до запуска)
  let frame = null;
  let running = false;
  let animStart = 0;
  let progress = 0;
  let canvasSize = { w: 0, h: 0 };
  let runCount = 0;
  const journal = [];

  const fmt = (n, d = 2) => Number(n).toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d });
  const fmtSigned = (n) => `${n >= 0 ? "+" : "−"}${fmt(Math.abs(n))}`;
  const sideName = (s) => (s === 1 ? "впереди Венеры" : "позади Венеры");

  function setPct(input) {
    const pct = (input.value - input.min) / (input.max - input.min) * 100;
    input.style.setProperty("--pct", `${pct}%`);
  }

  function updateLabels() {
    const v = Number(speedInput.value), h = Number(altitudeInput.value);
    $("speedOut").textContent = `${fmt(v, 1)} км/с`;
    $("altitudeOut").textContent = `${Math.round(h).toLocaleString("ru-RU")} км`;
    setPct(speedInput); setPct(altitudeInput);
    const zone = $("zoneNote");
    if (h <= 0) { zone.className = "zone-note danger"; zone.textContent = "Траектория касается поверхности — столкновение"; }
    else if (h < ATMOSPHERE_ALT) { zone.className = "zone-note warn"; zone.textContent = `Ниже ${ATMOSPHERE_ALT} км — плотная атмосфера, аппарат будет потерян`; }
    else { zone.className = "zone-note safe"; zone.textContent = "Безопасная высота"; }
  }

  function resetTelemetry() {
    ["timeReadout", "currentSpeed", "currentAltitude"].forEach(id => { $(id).textContent = "—"; });
  }

  function setBadge(text, cls = "") {
    $("flightBadge").textContent = text;
    $("flightBadge").className = `badge ${cls}`.trim();
  }

  // Любое изменение настроек: показываем предпросмотр подлёта по новым параметрам.
  function onParamsChange() {
    updateLabels();
    if (running) return;
    const hadResult = !!result;
    result = null;
    progress = 0;
    preview = calculateFlyby(Number(speedInput.value), Number(altitudeInput.value), side);
    if (hadResult) {
      resetTelemetry();
      setBadge("ПАРАМЕТРЫ ИЗМЕНЕНЫ");
      $("canvasHint").textContent = "Параметры изменены — нажми «Запустить манёвр»";
    }
    drawScene();
  }
  speedInput.addEventListener("input", onParamsChange);
  altitudeInput.addEventListener("input", onParamsChange);

  sideButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      if (running) return;
      side = Number(btn.dataset.side);
      sideButtons.forEach(b => {
        const on = b === btn;
        b.classList.toggle("active", on);
        b.setAttribute("aria-pressed", String(on));
      });
      onParamsChange();
    });
  });

  function lockControls(lock) {
    speedInput.disabled = lock;
    altitudeInput.disabled = lock;
    sideButtons.forEach(b => { b.disabled = lock; });
    resetBtn.disabled = false;
  }

  /* ---------- Рисование ---------- */
  function fitCanvas() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    canvasSize = { w: rect.width, h: rect.height };
    drawScene();
  }

  function makeTransform(bounds) {
    const { w, h } = canvasSize;
    const padX = 28, padTop = 46, padBottom = 44;
    const spanX = bounds.maxX - bounds.minX, spanY = bounds.maxY - bounds.minY;
    const scale = Math.min((w - 2 * padX) / spanX, (h - padTop - padBottom) / spanY);
    const cx = (bounds.minX + bounds.maxX) / 2, cy = (bounds.minY + bounds.maxY) / 2;
    return {
      scale,
      sx: x => w / 2 + (x - cx) * scale,
      sy: y => padTop + (h - padTop - padBottom) / 2 - (y - cy) * scale
    };
  }

  function arrow(x1, y1, x2, y2, color) {
    const a = Math.atan2(y2 - y1, x2 - x1);
    ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - 7 * Math.cos(a - 0.45), y2 - 7 * Math.sin(a - 0.45));
    ctx.lineTo(x2 - 7 * Math.cos(a + 0.45), y2 - 7 * Math.sin(a + 0.45));
    ctx.closePath(); ctx.fill();
  }

  function strokePath(list, tr, color, dashed, alpha = 1, width = 2.4) {
    if (list.length < 2) return;
    ctx.beginPath();
    list.forEach((p, i) => {
      const x = tr.sx(p[0]), y = tr.sy(p[1]);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineJoin = "round"; ctx.lineCap = "round";
    ctx.globalAlpha = alpha; ctx.setLineDash(dashed ? [6, 5] : []);
    ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
  }

  function drawScene() {
    const { w, h } = canvasSize;
    if (!w || !h) return;
    const res = result || preview;
    if (!res) return;
    const isPreview = !result;
    const amount = isPreview ? 0 : progress;

    ctx.clearRect(0, 0, w, h);
    const bg = ctx.createLinearGradient(0, 0, w, h);
    bg.addColorStop(0, "#091323"); bg.addColorStop(1, "#060b15");
    ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);

    // Звёзды — фиксированные позиции, чтобы картинка не мерцала.
    for (let i = 0; i < 80; i++) {
      const x = (i * 127.7 + 19) % w, y = (i * 71.3 + 11) % h;
      ctx.fillStyle = i % 7 === 0 ? "#668ca5" : "#52647d";
      ctx.globalAlpha = 0.25 + (i % 5) * 0.1;
      ctx.fillRect(x, y, i % 9 === 0 ? 2 : 1, i % 9 === 0 ? 2 : 1);
    }
    ctx.globalAlpha = 1;

    const tr = makeTransform(res.bounds);
    const cx = tr.sx(0), cy = tr.sy(0);
    const radius = Math.max(8, VENUS_RADIUS * tr.scale);

    // Граница атмосферы.
    const atmR = Math.max(radius + 2, (VENUS_RADIUS + ATMOSPHERE_ALT) * tr.scale);
    const glow = ctx.createRadialGradient(cx, cy, radius * 0.9, cx, cy, radius * 2.4);
    glow.addColorStop(0, "#d88a4e55"); glow.addColorStop(1, "#d88a4e00");
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(cx, cy, radius * 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, atmR, 0, Math.PI * 2);
    ctx.strokeStyle = "#ffb36b88"; ctx.lineWidth = 1; ctx.setLineDash([2, 3]); ctx.stroke(); ctx.setLineDash([]);

    // Планета.
    const planet = ctx.createRadialGradient(cx - radius * 0.35, cy - radius * 0.4, radius * 0.08, cx, cy, radius);
    planet.addColorStop(0, "#f4c18a"); planet.addColorStop(0.45, "#bd7548"); planet.addColorStop(1, "#673a32");
    ctx.fillStyle = planet; ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.clip();
    ctx.globalAlpha = 0.18; ctx.strokeStyle = "#ffd2a1"; ctx.lineWidth = Math.max(2, radius * 0.18);
    for (let i = -3; i <= 3; i++) {
      ctx.beginPath(); ctx.ellipse(cx + radius * 0.1, cy + i * radius * 0.24, radius * 0.95, radius * 0.13, -0.3, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
    ctx.fillStyle = "#f2c69d"; ctx.font = "10px 'DM Mono', monospace"; ctx.textAlign = "center";
    ctx.fillText("ВЕНЕРА", cx, cy + radius + 15);

    // Траектория.
    const pts = res.points, ci = res.closestIndex;
    if (isPreview) {
      strokePath(pts.slice(0, ci + 1), tr, "#5ee4df", true, 0.5, 2);
    } else if (amount > 0) {
      const { head, count } = headAt(res, amount);
      const visible = pts.slice(0, count).concat([head]);
      strokePath(visible.slice(0, Math.min(ci, visible.length - 1) + 1), tr, "#5ee4df", false);
      if (visible.length - 1 > ci) strokePath(visible.slice(ci), tr, "#ffb36b", true);
    }

    // Точка ближайшего сближения и высота пролёта.
    const showClosest = isPreview || amount >= 1 || (headAt(res, amount).count >= ci && amount > 0);
    if (showClosest) {
      const c = pts[ci];
      const px = tr.sx(c[0]), py = tr.sy(c[1]);
      const dist = Math.hypot(px - cx, py - cy) || 1;
      const sxp = cx + (px - cx) / dist * radius, syp = cy + (py - cy) / dist * radius;
      ctx.strokeStyle = "#ffffffaa"; ctx.lineWidth = 1; ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(sxp, syp); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = res.failed && !isPreview ? "#ff7e86" : "#fff";
      ctx.beginPath(); ctx.arc(px, py, 4, 0, Math.PI * 2); ctx.fill();
      const label = `H = ${Math.round(res.minAltitude).toLocaleString("ru-RU")} км`;
      ctx.font = "10px 'DM Mono', monospace"; ctx.textAlign = "left";
      const tw = ctx.measureText(label).width;
      const lx = Math.min(w - tw - 8, Math.max(8, px + 9));
      const ly = py < cy ? Math.max(14, py - 9) : Math.min(h - 8, py + 15);
      ctx.fillStyle = "#e8eef8"; ctx.fillText(label, lx, ly);
    }

    // Аппарат.
    if (!isPreview && amount > 0) {
      const { head } = headAt(res, amount);
      const px = tr.sx(head[0]), py = tr.sy(head[1]);
      const ang = Math.atan2(-head[3], head[2]);
      const crashedNow = amount >= 1 && res.failed;
      ctx.save(); ctx.translate(px, py); ctx.rotate(ang);
      ctx.shadowColor = crashedNow ? "#ff7e86" : "#fff"; ctx.shadowBlur = 12;
      ctx.fillStyle = crashedNow ? "#ff7e86" : "#fff";
      ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(-5, -4.5); ctx.lineTo(-3, 0); ctx.lineTo(-5, 4.5); ctx.closePath(); ctx.fill();
      ctx.restore();
      if (crashedNow) {
        ctx.strokeStyle = "#ff7e86"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(px, py, 11, 0, Math.PI * 2); ctx.stroke();
      }
    }

    // Подсказка направлений (левый верхний угол).
    ctx.font = "9px 'DM Mono', monospace"; ctx.textAlign = "left";
    arrow(14, 26, 44, 26, "#5ee4df");
    ctx.fillStyle = "#a7c9d0"; ctx.fillText("АППАРАТ", 52, 29);
    arrow(20, 56, 20, 36, "#9fb0c8");
    ctx.fillStyle = "#9fb0c8"; ctx.fillText("ВЕНЕРА 35,02 км/с", 30, 50);
  }

  /* ---------- Результаты ---------- */
  function showTelemetry(p) {
    $("timeReadout").textContent = `${fmt(p[4] / 3600, 1)} ч`;
    $("currentSpeed").textContent = `${fmt(Math.hypot(p[2], p[3]))} км/с`;
    $("currentAltitude").textContent = `${fmt(Math.max(0, Math.hypot(p[0], p[1]) - VENUS_RADIUS), 0)} км`;
  }

  function setOutcome(kind, icon, title, text) {
    const o = $("outcome");
    o.className = `outcome ${kind}`;
    o.innerHTML = "";
    const i = document.createElement("span"); i.className = "outcome-icon"; i.textContent = icon;
    const d = document.createElement("div");
    const s = document.createElement("strong"); s.textContent = title;
    const p = document.createElement("p"); p.textContent = text;
    d.append(s, p); o.append(i, d);
  }

  function classify(r) {
    if (r.failed) return "failure";
    return Math.abs(r.delta) >= MIN_USEFUL_DELTA ? "success" : "neutral";
  }

  function showResult(r) {
    $("beforeSpeed").textContent = `${fmt(r.beforeHelio)} км/с`;
    $("beforeRelative").textContent = `${fmt(r.incomingRelative)} км/с`;
    $("closestAltitude").textContent = `${fmt(r.minAltitude, 0)} км`;
    const status = classify(r);

    if (r.failed) {
      ["afterSpeed", "afterRelative", "deltaSpeed", "deflection"].forEach(id => { $(id).textContent = "—"; });
      if (r.crashed) {
        setOutcome("failure", "!", "Неудача: столкновение с Венерой",
          "Траектория проходит через поверхность планеты (высота пролёта 0 км). Увеличь высоту пролёта и попробуй снова.");
      } else {
        setOutcome("failure", "!", "Неудача: аппарат потерян в атмосфере",
          `Высота пролёта ${fmt(r.minAltitude, 0)} км ниже безопасного порога ${ATMOSPHERE_ALT} км: в плотной атмосфере аппарат сгорит и не выйдет на расчётную траекторию. Подними высоту.`);
      }
      setBadge("АВАРИЯ", "");
    } else {
      $("afterSpeed").textContent = `${fmt(r.afterHelio)} км/с`;
      $("afterRelative").textContent = `${fmt(r.outgoingRelative)} км/с`;
      $("deltaSpeed").textContent = `${fmtSigned(r.delta)} км/с`;
      $("deflection").textContent = `${fmt(r.turnAngle, 1)}°`;
      const why = r.side === 1
        ? "Аппарат прошёл впереди Венеры: её притяжение тянуло его назад по орбите, поэтому скорость относительно Солнца уменьшилась."
        : "Аппарат прошёл позади Венеры: её притяжение тянуло его вперёд по орбите, поэтому скорость относительно Солнца выросла.";
      const keep = `Относительно самой Венеры скорость осталась ${fmt(r.incomingRelative)} км/с — изменилось только её направление (поворот на ${fmt(r.turnAngle, 1)}°).`;
      if (status === "success") {
        setOutcome("success", "✓", `Манёвр успешен: аппарат ${r.delta > 0 ? "ускорился" : "замедлился"} на ${fmt(Math.abs(r.delta))} км/с`,
          `${why} ${keep} Критерии выполнены: высота не ниже ${ATMOSPHERE_ALT} км и |ΔV| ≥ ${fmt(MIN_USEFUL_DELTA, 1)} км/с.`);
      } else {
        setOutcome("neutral", "◎", "Пролёт безопасен, эффект небольшой",
          `Изменение скорости ${fmtSigned(r.delta)} км/с по модулю меньше ${fmt(MIN_USEFUL_DELTA, 1)} км/с. ${keep} Попробуй уменьшить высоту или скорость — отклонение будет сильнее.`);
      }
      setBadge("РАСЧЁТ ЗАВЕРШЁН", "done");
    }
    $("canvasHint").textContent = r.failed ? "Аппарат потерян у Венеры — попробуй другую высоту" : "Показана траектория до и после пролёта";
    addJournal(r, status);
  }

  /* ---------- Журнал ---------- */
  function addJournal(r, status) {
    runCount++;
    journal.unshift({
      n: runCount, v: r.vInf, h: r.minAltitude, side: r.side,
      delta: r.failed ? null : r.delta, status
    });
    if (journal.length > 8) journal.pop();
    renderJournal();
  }

  function renderJournal() {
    const body = $("journalBody");
    body.innerHTML = "";
    if (!journal.length) {
      const tr = document.createElement("tr"); tr.className = "empty";
      const td = document.createElement("td"); td.colSpan = 6;
      td.textContent = "Пока нет запусков. Меняй параметры и сравнивай результаты.";
      tr.append(td); body.append(tr); return;
    }
    const labels = { success: "Успех", neutral: "Слабый эффект", failure: "Неудача" };
    journal.forEach(j => {
      const tr = document.createElement("tr");
      const cells = [
        j.n, `${fmt(j.v, 1)} км/с`, `${Math.round(j.h).toLocaleString("ru-RU")} км`,
        j.side === 1 ? "Впереди" : "Позади",
        j.delta === null ? "—" : `${fmtSigned(j.delta)} км/с`
      ];
      cells.forEach(c => { const td = document.createElement("td"); td.textContent = c; tr.append(td); });
      const st = document.createElement("td"); st.className = `st-${j.status}`; st.textContent = labels[j.status];
      tr.append(st); body.append(tr);
    });
  }

  $("clearJournal").addEventListener("click", () => { journal.length = 0; runCount = 0; renderJournal(); });

  /* ---------- Запуск, анимация, сброс ---------- */
  function animate(ts) {
    if (!animStart) animStart = ts;
    progress = Math.min(1, (ts - animStart) / ANIMATION_MS);
    drawScene();
    showTelemetry(headAt(result, progress).head);
    if (progress < 1) {
      frame = requestAnimationFrame(animate);
    } else {
      finishRun();
    }
  }

  function finishRun() {
    frame = null; running = false;
    lockControls(false);
    launchBtn.disabled = false;
    launchBtn.innerHTML = "↻ &nbsp; Повторить манёвр";
    progress = 1;
    drawScene();
    showTelemetry(result.points[result.points.length - 1]);
    showResult(result);
  }

  function launch() {
    if (running) return;
    if (frame) cancelAnimationFrame(frame);
    result = calculateFlyby(Number(speedInput.value), Number(altitudeInput.value), side);
    progress = 0; animStart = 0; running = true;
    lockControls(true);
    launchBtn.disabled = true;
    launchBtn.textContent = "МОДЕЛИРОВАНИЕ…";
    setBadge("МОДЕЛИРОВАНИЕ", "running");
    $("canvasHint").textContent = "Аппарат приближается к Венере…";
    setOutcome("neutral", "◌", "Выполняется расчёт", "Численное интегрирование движения аппарата в гравитационном поле Венеры.");
    if (reducedMotion) { finishRun(); return; }
    frame = requestAnimationFrame(animate);
  }

  function reset() {
    if (frame) cancelAnimationFrame(frame);
    frame = null; running = false; result = null; progress = 0;
    speedInput.value = 10; altitudeInput.value = 1000; side = 1;
    sideButtons.forEach(b => {
      const on = b.dataset.side === "1";
      b.classList.toggle("active", on); b.setAttribute("aria-pressed", String(on));
    });
    lockControls(false);
    updateLabels();
    ["beforeSpeed", "afterSpeed", "deltaSpeed", "beforeRelative", "afterRelative", "deflection", "closestAltitude"]
      .forEach(id => { $(id).textContent = "—"; });
    resetTelemetry();
    setBadge("ОЖИДАНИЕ");
    $("canvasHint").textContent = "Настрой параметры и нажми «Запустить манёвр»";
    setOutcome("neutral", "◎", "Ожидание результата", "Запусти моделирование, чтобы увидеть итог манёвра и объяснение расчёта.");
    launchBtn.disabled = false;
    launchBtn.innerHTML = "▶ &nbsp; Запустить манёвр";
    preview = calculateFlyby(10, 1000, 1);
    drawScene();
  }

  launchBtn.addEventListener("click", launch);
  resetBtn.addEventListener("click", reset);
  if ("ResizeObserver" in window) new ResizeObserver(fitCanvas).observe(canvas.parentElement);
  else window.addEventListener("resize", fitCanvas);

  updateLabels();
  preview = calculateFlyby(Number(speedInput.value), Number(altitudeInput.value), side);
  fitCanvas();
})();
